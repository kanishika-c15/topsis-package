# TOPSIS Implementation in Python

Name: Kanishika  
Roll Number: 102317021  

## Description
This project implements the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) method using Python.  
The program works as a command line tool.

## Usage
```bash
python topsis.py <inputfile> <weights> <impacts> <outputfile>
